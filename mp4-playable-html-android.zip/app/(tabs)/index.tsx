import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import * as DocumentPicker from "expo-document-picker";
import * as Haptics from "expo-haptics";
import { useKeepAwake } from "expo-keep-awake";
import * as Sharing from "expo-sharing";
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { estimateHtmlBytes } from "@/lib/mp4-html-format";
import { convertMp4ToPlayableHtml, type LocalConversionResult } from "@/lib/mp4-html";
import { convertBrowserMp4ToPlayableHtml } from "@/lib/mp4-html-web";

type PickedVideo = {
  name: string;
  size: number;
  uri: string;
  browserFile?: Blob;
};

type ConverterStatus = "empty" | "selected" | "converting" | "complete" | "error";

const KEEP_AWAKE_TAG = "mp4-to-playable-html-conversion";

function ConversionWakeLock() {
  useKeepAwake(KEEP_AWAKE_TAG, { suppressDeactivateWarnings: true });
  return null;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(bytes >= 1024 * 1024 * 1024 ? 2 : 1)} MB`;
}

function isMp4(asset: DocumentPicker.DocumentPickerAsset): boolean {
  return asset.mimeType === "video/mp4" || /\.mp4$/i.test(asset.name);
}

export default function HomeScreen() {
  const [status, setStatus] = useState<ConverterStatus>("empty");
  const [video, setVideo] = useState<PickedVideo | null>(null);
  const [progress, setProgress] = useState({ processedBytes: 0, totalBytes: 0 });
  const [result, setResult] = useState<LocalConversionResult | null>(null);
  const [errorMessage, setErrorMessage] = useState("");

  const progressPercent = useMemo(() => {
    if (progress.totalBytes <= 0) return 0;
    return Math.min(100, Math.round((progress.processedBytes / progress.totalBytes) * 100));
  }, [progress]);

  const pickVideo = useCallback(async () => {
    if (Platform.OS !== "web") {
      void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    setErrorMessage("");
    const selection = await DocumentPicker.getDocumentAsync({
      type: "video/mp4",
      multiple: false,
      copyToCacheDirectory: true,
      base64: false,
    });
    if (selection.canceled) return;

    const asset = selection.assets[0];
    if (!isMp4(asset)) {
      setStatus("error");
      setErrorMessage("Please choose an MP4 video file.");
      return;
    }
    if (!asset.size || asset.size <= 0) {
      setStatus("error");
      setErrorMessage("The file size is unavailable. Please choose a different MP4.");
      return;
    }

    if (Platform.OS === "web" && !asset.file) {
      setStatus("error");
      setErrorMessage("Your browser did not provide access to the selected MP4. Please try again in a current browser.");
      return;
    }

    setVideo({ name: asset.name, size: asset.size, uri: asset.uri, browserFile: asset.file });
    setResult(null);
    setProgress({ processedBytes: 0, totalBytes: asset.size });
    setStatus("selected");
  }, []);

  const convert = useCallback(async () => {
    if (!video) return;
    if (Platform.OS !== "web") {
      void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    setStatus("converting");
    setErrorMessage("");
    setProgress({ processedBytes: 0, totalBytes: video.size });

    try {
      const completed =
        Platform.OS === "web" && video.browserFile
          ? await convertBrowserMp4ToPlayableHtml(video.browserFile, video.name, setProgress)
          : await convertMp4ToPlayableHtml({
              sourceUri: video.uri,
              sourceName: video.name,
              sourceSize: video.size,
              onProgress: setProgress,
            });
      setResult(completed);
      setStatus("complete");
      if (Platform.OS !== "web") {
        void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
    } catch (error) {
      setStatus("error");
      setErrorMessage(error instanceof Error ? error.message : "The conversion could not be completed.");
      if (Platform.OS !== "web") {
        void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      }
    }
  }, [video]);

  const shareResult = useCallback(async () => {
    if (!result) return;
    try {
      if (Platform.OS === "web") {
        const downloadLink = document.createElement("a");
        downloadLink.href = result.outputUri;
        downloadLink.download = result.outputName;
        document.body.appendChild(downloadLink);
        downloadLink.click();
        downloadLink.remove();
        return;
      }
      if (!(await Sharing.isAvailableAsync())) {
        Alert.alert("Sharing unavailable", "This device does not currently provide a share sheet.");
        return;
      }
      await Sharing.shareAsync(result.outputUri, {
        dialogTitle: `Save or share ${result.outputName}`,
        mimeType: "text/html",
      });
    } catch {
      Alert.alert("Unable to open sharing", "The HTML was created, but the share sheet could not be opened.");
    }
  }, [result]);

  const reset = useCallback(() => {
    if (Platform.OS === "web" && result) {
      URL.revokeObjectURL(result.outputUri);
    }
    setVideo(null);
    setResult(null);
    setErrorMessage("");
    setProgress({ processedBytes: 0, totalBytes: 0 });
    setStatus("empty");
  }, [result]);

  const hasSelection = status === "selected" || status === "converting";
  const canConvert = status === "selected" && video !== null;

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]} containerClassName="bg-background">
      {status === "converting" && <ConversionWakeLock />}
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View style={styles.brandMark}>
            <MaterialIcons name="play-circle-filled" size={30} color="#AFC8FF" />
          </View>
          <Text style={styles.eyebrow}>LOCAL VIDEO UTILITY</Text>
          <Text style={styles.title}>MP4 to{`\n`}playable HTML</Text>
          <Text style={styles.subtitle}>
            Make one self-contained HTML file, entirely on this device.
          </Text>
        </View>

        <View style={styles.privacyPill}>
          <MaterialIcons name="lock-outline" size={15} color="#87E6C5" />
          <Text style={styles.privacyText}>No upload. No account. Your video stays on this phone.</Text>
        </View>

        {(status === "empty" || status === "error") && (
          <View style={[styles.card, status === "error" && styles.errorCard]}>
            <View style={styles.cardIcon}>
              <MaterialIcons name={status === "error" ? "error-outline" : "movie-creation"} size={32} color={status === "error" ? "#FF9D9D" : "#AFC8FF"} />
            </View>
            <Text style={styles.cardTitle}>{status === "error" ? "Let’s try that again" : "Choose an MP4"}</Text>
            <Text style={styles.cardDescription}>
              {status === "error" ? errorMessage : "The original video is embedded in HTML. The output is about 33% larger."}
            </Text>
            <Pressable onPress={pickVideo} style={({ pressed }) => [styles.primaryButton, pressed && styles.pressedButton]}>
              <MaterialIcons name="folder-open" size={21} color="#07101E" />
              <Text style={styles.primaryButtonText}>{status === "error" ? "Choose another MP4" : "Choose MP4"}</Text>
            </Pressable>
          </View>
        )}

        {hasSelection && video && (
          <View style={styles.card}>
            <View style={styles.fileTitleRow}>
              <View style={styles.fileIcon}>
                <MaterialIcons name="movie" size={23} color="#AFC8FF" />
              </View>
              <View style={styles.fileNameBlock}>
                <Text style={styles.fileLabel}>SELECTED VIDEO</Text>
                <Text numberOfLines={2} style={styles.fileName}>{video.name}</Text>
              </View>
            </View>
            <View style={styles.statRow}>
              <View style={styles.statCell}>
                <Text style={styles.statLabel}>MP4 SIZE</Text>
                <Text style={styles.statValue}>{formatBytes(video.size)}</Text>
              </View>
              <View style={styles.statDivider} />
              <View style={styles.statCell}>
                <Text style={styles.statLabel}>HTML ESTIMATE</Text>
                <Text style={styles.statValue}>{formatBytes(estimateHtmlBytes(video.size))}</Text>
              </View>
            </View>

            {status === "converting" ? (
              <View style={styles.progressSection}>
                <View style={styles.progressHeader}>
                  <Text style={styles.progressLabel}>CONVERTING LOCALLY</Text>
                  <Text style={styles.progressPercent}>{progressPercent}%</Text>
                </View>
                <View style={styles.progressTrack}>
                  <View style={[styles.progressFill, { width: `${progressPercent}%` }]} />
                </View>
                <Text style={styles.progressDescription}>
                  {formatBytes(progress.processedBytes)} of {formatBytes(progress.totalBytes)} encoded. Keep this screen open.
                </Text>
              </View>
            ) : (
              <View style={styles.actionGroup}>
                <Pressable onPress={convert} disabled={!canConvert} style={({ pressed }) => [styles.primaryButton, !canConvert && styles.disabledButton, pressed && canConvert && styles.pressedButton]}>
                  <MaterialIcons name="bolt" size={21} color="#07101E" />
                  <Text style={styles.primaryButtonText}>Create playable HTML</Text>
                </Pressable>
                <Pressable onPress={pickVideo} style={({ pressed }) => [styles.textButton, pressed && styles.pressedTextButton]}>
                  <Text style={styles.textButtonLabel}>Replace video</Text>
                </Pressable>
              </View>
            )}
          </View>
        )}

        {status === "complete" && result && (
          <View style={[styles.card, styles.successCard]}>
            <View style={styles.successBadge}>
              <MaterialIcons name="check" size={22} color="#05231A" />
            </View>
            <Text style={styles.cardTitle}>Your HTML is ready</Text>
            <Text style={styles.cardDescription}>The MP4 was converted locally and saved with its original name.</Text>
            <View style={styles.resultFileRow}>
              <MaterialIcons name="description" size={21} color="#87E6C5" />
              <View style={styles.fileNameBlock}>
                <Text style={styles.fileLabel}>OUTPUT FILE</Text>
                <Text numberOfLines={2} style={styles.resultFileName}>{result.outputName}</Text>
              </View>
              <Text style={styles.resultSize}>{formatBytes(result.outputSize)}</Text>
            </View>
            <Pressable onPress={shareResult} style={({ pressed }) => [styles.primaryButton, styles.shareButton, pressed && styles.pressedButton]}>
              <MaterialIcons name="ios-share" size={21} color="#07101E" />
              <Text style={styles.primaryButtonText}>Save or share HTML</Text>
            </Pressable>
            <Pressable onPress={reset} style={({ pressed }) => [styles.textButton, pressed && styles.pressedTextButton]}>
              <Text style={styles.textButtonLabel}>Convert another MP4</Text>
            </Pressable>
          </View>
        )}

        <View style={styles.bottomNote}>
          <MaterialIcons name="info-outline" size={17} color="#7E8BA8" />
          <Text style={styles.bottomNoteText}>For best results, open the generated file in a modern browser.</Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scrollContent: { flexGrow: 1, paddingHorizontal: 20, paddingTop: 18, paddingBottom: 30 },
  header: { marginTop: 12, alignItems: "flex-start" },
  brandMark: { width: 48, height: 48, alignItems: "center", justifyContent: "center", borderRadius: 16, backgroundColor: "#19284A", borderWidth: 1, borderColor: "#2C4680" },
  eyebrow: { marginTop: 20, color: "#8DA8E8", fontSize: 11, lineHeight: 16, fontWeight: "800", letterSpacing: 1.6 },
  title: { marginTop: 7, color: "#F5F8FF", fontSize: 38, lineHeight: 42, fontWeight: "800", letterSpacing: -1.4 },
  subtitle: { marginTop: 12, maxWidth: 320, color: "#AAB7D2", fontSize: 16, lineHeight: 23 },
  privacyPill: { flexDirection: "row", alignItems: "center", gap: 8, alignSelf: "flex-start", marginTop: 22, paddingHorizontal: 12, paddingVertical: 9, borderRadius: 100, backgroundColor: "#102B2B", borderWidth: 1, borderColor: "#245A52" },
  privacyText: { color: "#B7F4DE", fontSize: 12, fontWeight: "600" },
  card: { marginTop: 22, padding: 20, borderRadius: 24, backgroundColor: "#151E33", borderWidth: 1, borderColor: "#24314E" },
  errorCard: { borderColor: "#773C4A", backgroundColor: "#251B2A" },
  successCard: { borderColor: "#2C6B5B", backgroundColor: "#112C2B" },
  cardIcon: { width: 52, height: 52, alignItems: "center", justifyContent: "center", borderRadius: 17, backgroundColor: "#1D2B4B" },
  cardTitle: { marginTop: 17, color: "#F5F8FF", fontSize: 21, lineHeight: 28, fontWeight: "700" },
  cardDescription: { marginTop: 7, color: "#AAB7D2", fontSize: 14, lineHeight: 21 },
  primaryButton: { minHeight: 52, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 9, marginTop: 20, paddingHorizontal: 18, borderRadius: 16, backgroundColor: "#AFC8FF" },
  primaryButtonText: { color: "#07101E", fontSize: 16, fontWeight: "800" },
  pressedButton: { opacity: 0.9, transform: [{ scale: 0.98 }] },
  disabledButton: { opacity: 0.5 },
  fileTitleRow: { flexDirection: "row", alignItems: "flex-start", gap: 12 },
  fileIcon: { width: 44, height: 44, alignItems: "center", justifyContent: "center", borderRadius: 14, backgroundColor: "#1D2B4B" },
  fileNameBlock: { flex: 1 },
  fileLabel: { color: "#8DA8E8", fontSize: 10, lineHeight: 14, fontWeight: "800", letterSpacing: 1.2 },
  fileName: { marginTop: 3, color: "#F5F8FF", fontSize: 16, lineHeight: 21, fontWeight: "700" },
  statRow: { flexDirection: "row", marginTop: 19, paddingTop: 17, borderTopWidth: 1, borderTopColor: "#263551" },
  statCell: { flex: 1 },
  statDivider: { width: 1, marginHorizontal: 12, backgroundColor: "#263551" },
  statLabel: { color: "#7E8BA8", fontSize: 10, fontWeight: "800", letterSpacing: 0.9 },
  statValue: { marginTop: 4, color: "#DCE7FF", fontSize: 14, fontWeight: "700" },
  actionGroup: { marginTop: 18 },
  textButton: { alignSelf: "center", minHeight: 44, alignItems: "center", justifyContent: "center", paddingHorizontal: 16, marginTop: 4 },
  textButtonLabel: { color: "#B4C9FF", fontSize: 14, fontWeight: "700" },
  pressedTextButton: { opacity: 0.6 },
  progressSection: { marginTop: 22 },
  progressHeader: { flexDirection: "row", alignItems: "baseline", justifyContent: "space-between" },
  progressLabel: { color: "#B4C9FF", fontSize: 11, fontWeight: "800", letterSpacing: 1 },
  progressPercent: { color: "#F5F8FF", fontSize: 24, fontWeight: "800" },
  progressTrack: { height: 10, marginTop: 10, overflow: "hidden", borderRadius: 100, backgroundColor: "#263551" },
  progressFill: { height: "100%", borderRadius: 100, backgroundColor: "#A974FF" },
  progressDescription: { marginTop: 10, color: "#AAB7D2", fontSize: 13, lineHeight: 18 },
  successBadge: { width: 42, height: 42, alignItems: "center", justifyContent: "center", borderRadius: 21, backgroundColor: "#87E6C5" },
  resultFileRow: { flexDirection: "row", alignItems: "center", gap: 10, marginTop: 18, padding: 13, borderRadius: 14, backgroundColor: "#0D2425" },
  resultFileName: { marginTop: 2, color: "#F5F8FF", fontSize: 14, lineHeight: 19, fontWeight: "700" },
  resultSize: { color: "#B7F4DE", fontSize: 12, fontWeight: "700" },
  shareButton: { backgroundColor: "#87E6C5" },
  bottomNote: { flexDirection: "row", alignItems: "flex-start", gap: 8, marginTop: 20, paddingHorizontal: 7 },
  bottomNoteText: { flex: 1, color: "#7E8BA8", fontSize: 12, lineHeight: 18 },
});
