# Mobile Interface Design — MP4 to Playable HTML

## Product Intent

**MP4 to Playable HTML** is a focused, offline utility for turning one selected MP4 into a self-contained HTML file. The interface is designed for a vertical 9:16 phone screen and one-handed use: the primary action sits in the lower half of the screen, conversion status stays readable at a glance, and the final share action is within easy thumb reach. No account, network connection, cloud upload, or Telegram connection is required.

## Screen List

| Screen or state | Primary content and functionality | Layout specification |
| --- | --- | --- |
| Converter home | A concise explanation, privacy assurance, a prominent MP4 selection control, and an optional selected-file summary. | A dark canvas with a restrained blue-to-violet accent. The heading occupies the top third, the selection card occupies the visual center, and the full-width primary button is anchored in the lower third. |
| File selected | The original filename, file size, estimated HTML size, replace action, and enabled conversion control. | The selection card changes into an information card. Filename wraps to two lines, while size information is presented as a compact two-column row. |
| Conversion in progress | A single stage label, percentage, bytes processed, animated progress bar, and an explanation that the screen should stay open. | The file card is replaced by a progress card with a large numerical percentage and a high-contrast linear meter. The primary action is disabled to prevent duplicate jobs. |
| Conversion complete | The generated `.html` filename, final size, success confirmation, Share / Save action, and Convert another action. | A success-tinted result card appears directly below the header. The share action is the dominant full-width control and the restart action remains secondary. |
| Error state | Plain-language error, recovery explanation, and a Try another file action. | The existing card switches to an error tint and preserves the primary button location so the recovery action is discoverable without scanning the screen. |

## Key User Flows

The primary flow begins when the user taps **Choose MP4**. Android’s system file picker filters to video files. After selection, the app immediately displays the original name, input size, and a Base64-based estimate of the final HTML size. The user then taps **Create playable HTML**. The app reads and encodes the source locally in chunks, updates a stage-specific progress indicator, writes the output into its private application folder, and then opens the native Android share sheet. From the share sheet, the user can save the file to device storage, send it through a messaging app, or open it with another compatible app.

If selection is cancelled, the previous screen remains unchanged. If the selected file is unsupported, unreadable, or cannot fit in available storage, the app shows a precise recovery message and returns the user to the selection action. At no point does the app upload the video or retain it beyond the current conversion result.

## Color Choices

The brand uses a near-black **Ink** background (`#0B1020`) that reduces visual glare while video-related work is in progress. **Electric Blue** (`#4C8DFF`) identifies the primary action and active progress. **Orchid** (`#A974FF`) provides a subtle visual gradient partner without competing with status information. Surface cards use **Slate** (`#151E33`), supporting labels use **Mist** (`#AAB7D2`), successful completion uses **Mint** (`#35D0A4`), and unrecoverable errors use **Coral** (`#FF6B6B`). The palette maintains high text contrast and reserves bright colors for interactive or meaningful state changes.

## Accessibility and Interaction Details

Controls use clear text labels alongside familiar file, conversion, and share icons. The main call-to-action has a minimum 48-point touch target. Progress is expressed in text as well as color and bar length, so conversion state does not rely on color perception. Long filenames are allowed to wrap rather than being silently truncated, and progress updates include both percentage and byte counts for assistive technologies.
