export const INPUT_CHUNK_BYTES = 384 * 1024; // 384 KiB; divisible by 3 and responsive on mid-range phones.

export const HTML_PREFIX = `<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body { margin: 0; background: black; display: flex; justify-content: center; align-items: center; height: 100vh; }
        video { width: 100%; height: auto; max-height: 100vh; }
    </style>
</head>
<body>

    <video controls autoplay loop playsinline>
        <source src="data:video/mp4;base64,`;

export const HTML_SUFFIX = `" type="video/mp4">
        Your device does not support this video format.
    </video>

</body>
</html>
`;

const BASE64_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
const BASE64_CODES = Uint8Array.from(BASE64_ALPHABET, (character) => character.charCodeAt(0));
const ASCII_STRING_BLOCK_SIZE = 16_384;

export function outputHtmlFileName(sourceName: string): string {
  const trimmedName = sourceName.trim() || "video.mp4";
  return /\.mp4$/i.test(trimmedName)
    ? `${trimmedName.slice(0, -4)}.html`
    : `${trimmedName}.html`;
}

export function estimateHtmlBytes(videoBytes: number): number {
  return Math.ceil(videoBytes / 3) * 4 + new TextEncoder().encode(HTML_PREFIX + HTML_SUFFIX).length;
}

/** Encode only the supplied bounded chunk; callers never construct a full-file Base64 string. */
export function encodeBase64Chunk(bytes: Uint8Array): string {
  const output = new Uint8Array(Math.ceil(bytes.length / 3) * 4);
  const lastCompleteOffset = bytes.length - (bytes.length % 3);
  let outputOffset = 0;
  let inputOffset = 0;

  for (; inputOffset < lastCompleteOffset; inputOffset += 3) {
    const value =
      (bytes[inputOffset] << 16) |
      (bytes[inputOffset + 1] << 8) |
      bytes[inputOffset + 2];
    output[outputOffset++] = BASE64_CODES[(value >>> 18) & 63];
    output[outputOffset++] = BASE64_CODES[(value >>> 12) & 63];
    output[outputOffset++] = BASE64_CODES[(value >>> 6) & 63];
    output[outputOffset++] = BASE64_CODES[value & 63];
  }

  const remainder = bytes.length - lastCompleteOffset;
  if (remainder === 1) {
    const value = bytes[lastCompleteOffset] << 16;
    output[outputOffset++] = BASE64_CODES[(value >>> 18) & 63];
    output[outputOffset++] = BASE64_CODES[(value >>> 12) & 63];
    output[outputOffset++] = 61;
    output[outputOffset++] = 61;
  } else if (remainder === 2) {
    const value = (bytes[lastCompleteOffset] << 16) | (bytes[lastCompleteOffset + 1] << 8);
    output[outputOffset++] = BASE64_CODES[(value >>> 18) & 63];
    output[outputOffset++] = BASE64_CODES[(value >>> 12) & 63];
    output[outputOffset++] = BASE64_CODES[(value >>> 6) & 63];
    output[outputOffset++] = 61;
  }

  const stringBlocks: string[] = [];
  for (let offset = 0; offset < output.length; offset += ASCII_STRING_BLOCK_SIZE) {
    stringBlocks.push(
      String.fromCharCode(...output.subarray(offset, offset + ASCII_STRING_BLOCK_SIZE)),
    );
  }
  return stringBlocks.join("");
}

export function buildPlayableHtml(base64Video: string): string {
  return `${HTML_PREFIX}${base64Video}${HTML_SUFFIX}`;
}
