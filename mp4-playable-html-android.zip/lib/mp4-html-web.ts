import {
  encodeBase64Chunk,
  HTML_PREFIX,
  HTML_SUFFIX,
  INPUT_CHUNK_BYTES,
  outputHtmlFileName,
} from "./mp4-html-format";

export type BrowserConversionProgress = {
  processedBytes: number;
  totalBytes: number;
};

export type BrowserConversionResult = {
  outputUri: string;
  outputName: string;
  outputSize: number;
};

const yieldToInterface = () =>
  new Promise<void>((resolve) => {
    if (typeof requestAnimationFrame === "function") {
      requestAnimationFrame(() => resolve());
      return;
    }
    setTimeout(resolve, 0);
  });

export async function convertBrowserMp4ToPlayableHtml(
  file: Blob,
  sourceName: string,
  onProgress?: (progress: BrowserConversionProgress) => void,
): Promise<BrowserConversionResult> {
  if (file.size <= 0) {
    throw new Error("The selected MP4 is empty or cannot be read.");
  }

  const htmlParts: BlobPart[] = [HTML_PREFIX];
  let processedBytes = 0;
  onProgress?.({ processedBytes, totalBytes: file.size });

  while (processedBytes < file.size) {
    const end = Math.min(processedBytes + INPUT_CHUNK_BYTES, file.size);
    const sourceChunk = new Uint8Array(await file.slice(processedBytes, end).arrayBuffer());
    if (sourceChunk.length === 0) {
      throw new Error("The selected MP4 ended unexpectedly while it was being read.");
    }
    htmlParts.push(encodeBase64Chunk(sourceChunk));
    processedBytes = end;
    onProgress?.({ processedBytes, totalBytes: file.size });
    await yieldToInterface();
  }

  htmlParts.push(HTML_SUFFIX);
  const htmlBlob = new Blob(htmlParts, { type: "text/html" });
  return {
    outputUri: URL.createObjectURL(htmlBlob),
    outputName: outputHtmlFileName(sourceName),
    outputSize: htmlBlob.size,
  };
}
