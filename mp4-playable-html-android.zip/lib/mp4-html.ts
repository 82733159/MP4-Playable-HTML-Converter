import { Directory, File, Paths } from "expo-file-system";

import {
  encodeBase64Chunk,
  estimateHtmlBytes,
  HTML_PREFIX,
  HTML_SUFFIX,
  INPUT_CHUNK_BYTES,
  outputHtmlFileName,
} from "@/lib/mp4-html-format";

const encoder = new TextEncoder();

export type ConversionProgress = {
  processedBytes: number;
  totalBytes: number;
};

export type LocalConversionInput = {
  sourceUri: string;
  sourceName: string;
  sourceSize: number;
  onProgress?: (progress: ConversionProgress) => void;
};

export type LocalConversionResult = {
  outputUri: string;
  outputName: string;
  outputSize: number;
};

const yieldToInterface = () =>
  new Promise<void>((resolve) => {
    if (typeof requestAnimationFrame === "function") {
      requestAnimationFrame(() => resolve());
      return;
    }
    setTimeout(resolve, 0);
  });

export async function convertMp4ToPlayableHtml({
  sourceUri,
  sourceName,
  sourceSize,
  onProgress,
}: LocalConversionInput): Promise<LocalConversionResult> {
  const sourceFile = new File(sourceUri);
  const totalBytes = sourceFile.size;
  if (!sourceFile.exists || totalBytes <= 0) {
    throw new Error("The selected MP4 is no longer available. Please choose it again.");
  }

  const outputName = outputHtmlFileName(sourceName);
  const requiredSpace = estimateHtmlBytes(totalBytes) + INPUT_CHUNK_BYTES;
  if (Paths.availableDiskSpace < requiredSpace) {
    throw new Error("There is not enough free device storage for the generated HTML file.");
  }

  const outputDirectory = new Directory(Paths.document, "playable-html");
  outputDirectory.create({ idempotent: true, intermediates: true });
  const outputFile = new File(outputDirectory, outputName);
  outputFile.create({ overwrite: true, intermediates: true });

  const sourceHandle = sourceFile.open();
  const outputHandle = outputFile.open();
  let processedBytes = 0;
  let conversionSucceeded = false;

  try {
    outputHandle.writeBytes(encoder.encode(HTML_PREFIX));
    onProgress?.({ processedBytes, totalBytes });

    while (processedBytes < totalBytes) {
      const requestedBytes = Math.min(INPUT_CHUNK_BYTES, totalBytes - processedBytes);
      const offsetBeforeRead = sourceHandle.offset ?? processedBytes;
      const readBuffer = sourceHandle.readBytes(requestedBytes);
      const offsetAfterRead = sourceHandle.offset ?? offsetBeforeRead + readBuffer.length;
      const bytesRead = offsetAfterRead - offsetBeforeRead;
      if (bytesRead <= 0) {
        throw new Error("The selected MP4 ended unexpectedly while it was being read.");
      }
      const bytes = readBuffer.subarray(0, bytesRead);
      outputHandle.writeBytes(encoder.encode(encodeBase64Chunk(bytes)));
      processedBytes = Math.min(offsetAfterRead, totalBytes);
      onProgress?.({ processedBytes, totalBytes });
      await yieldToInterface();
    }

    outputHandle.writeBytes(encoder.encode(HTML_SUFFIX));
    conversionSucceeded = true;
  } finally {
    sourceHandle.close();
    outputHandle.close();
    if (!conversionSucceeded && outputFile.exists) {
      outputFile.delete();
    }
  }

  return {
    outputUri: outputFile.uri,
    outputName,
    outputSize: outputFile.size,
  };
}
