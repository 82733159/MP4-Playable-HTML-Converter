# Browser Preview Conversion Findings

The project’s Android conversion path uses Expo FileSystem handles. The installed Expo FileSystem web implementation explicitly reports that it is not supported on web, which explains the preview’s conversion failure after the first displayed percentage. The Android application continues to use its native file-handle path.

For the browser preview, Expo DocumentPicker provides a browser `File` object after user selection. The standard browser `File` interface is a `Blob`, allowing each slice to be read through `arrayBuffer()` without loading the entire video into memory. The browser path can write the completed HTML to a `Blob`, then create an object URL for download.

References:

- https://docs.expo.dev/versions/latest/sdk/document-picker/
- https://developer.mozilla.org/en-US/docs/Web/API/File
