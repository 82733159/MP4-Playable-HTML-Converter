from pathlib import Path

from PIL import Image


SOURCE = Path("/home/ubuntu/upload/81725a70-a229-11f1-8b2f-1343dbe35383.webp")
OUTPUTS = (
    Path("/home/ubuntu/mp4-playable-html-android/assets/images/icon.png"),
    Path("/home/ubuntu/mp4-playable-html-android/assets/images/splash-icon.png"),
    Path("/home/ubuntu/mp4-playable-html-android/assets/images/favicon.png"),
    Path("/home/ubuntu/mp4-playable-html-android/assets/images/android-icon-foreground.png"),
)


def main() -> None:
    with Image.open(SOURCE) as image:
        square_icon = image.convert("RGB").resize((512, 512), Image.Resampling.LANCZOS)
        for output in OUTPUTS:
            square_icon.save(output, format="PNG", optimize=True, compress_level=9)


if __name__ == "__main__":
    main()
