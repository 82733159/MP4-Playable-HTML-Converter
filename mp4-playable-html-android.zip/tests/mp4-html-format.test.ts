import { describe, expect, it } from "vitest";

import {
  buildPlayableHtml,
  encodeBase64Chunk,
  estimateHtmlBytes,
  outputHtmlFileName,
} from "../lib/mp4-html-format";
import { convertBrowserMp4ToPlayableHtml } from "../lib/mp4-html-web";

describe("MP4 playable HTML helpers", () => {
  it("preserves the original filename and changes only the MP4 extension", () => {
    expect(outputHtmlFileName("My original clip.MP4")).toBe("My original clip.html");
    expect(outputHtmlFileName("café_日本語.mp4")).toBe("café_日本語.html");
    expect(outputHtmlFileName("capture")).toBe("capture.html");
  });

  it("encodes arbitrary chunk content using Base64", () => {
    const bytes = new Uint8Array(786_435);
    for (let index = 0; index < bytes.length; index += 1) {
      bytes[index] = index % 256;
    }
    expect(encodeBase64Chunk(bytes)).toBe(Buffer.from(bytes).toString("base64"));
  });

  it("creates a playable HTML wrapper and a conservative size estimate", () => {
    const html = buildPlayableHtml("AAEC");
    expect(html).toContain('src="data:video/mp4;base64,AAEC"');
    expect(estimateHtmlBytes(50 * 1024 * 1024)).toBeGreaterThan(50 * 1024 * 1024);
  });

  it("converts a browser-selected MP4 in bounded chunks and reports complete progress", async () => {
    const sourceBytes = new Uint8Array(900_003);
    for (let index = 0; index < sourceBytes.length; index += 1) {
      sourceBytes[index] = index % 256;
    }
    const updates: number[] = [];
    const result = await convertBrowserMp4ToPlayableHtml(new Blob([sourceBytes]), "demo.mp4", (progress) => {
      updates.push(progress.processedBytes);
    });

    const html = await (await fetch(result.outputUri)).text();
    URL.revokeObjectURL(result.outputUri);
    expect(result.outputName).toBe("demo.html");
    expect(result.outputSize).toBeGreaterThan(sourceBytes.length);
    expect(updates[0]).toBe(0);
    expect(updates.at(-1)).toBe(sourceBytes.length);
    expect(html).toContain('src="data:video/mp4;base64,');
  });
});
