/** @type {const} */
const themeColors = {
  primary: { light: "#4C8DFF", dark: "#4C8DFF" },
  background: { light: "#0B1020", dark: "#0B1020" },
  surface: { light: "#151E33", dark: "#151E33" },
  foreground: { light: "#F5F8FF", dark: "#F5F8FF" },
  muted: { light: "#AAB7D2", dark: "#AAB7D2" },
  border: { light: "#24314E", dark: "#24314E" },
  success: { light: "#35D0A4", dark: "#35D0A4" },
  warning: { light: "#FFC76A", dark: "#FFC76A" },
  error: { light: "#FF6B6B", dark: "#FF6B6B" },
};

module.exports = { themeColors };
