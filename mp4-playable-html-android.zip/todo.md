# Project TODO

- [x] Install and configure the on-device document picker, filesystem, sharing, haptics, and keep-awake modules.
- [x] Implement an offline, chunked MP4-to-Base64 HTML conversion utility that preserves the original filename.
- [x] Build the one-handed mobile converter interface with selection, conversion progress, error, completion, and native share flows.
- [x] Apply the MP4 to Playable HTML visual system and update mobile navigation.
- [x] Add automated tests for HTML generation, output filename preservation, size estimation, and conversion state helpers.
- [x] Generate and configure a custom mobile application icon and app branding.
- [x] Validate TypeScript, automated tests, and Expo configuration for APK publishing.
- [ ] Provide the user with the checkpointed project and the Publish-button steps that generate the Android APK.
- [x] Optimize the supplied icon into compact release-safe assets.
- [x] Retry the release checkpoint now that all app media files meet the size limit.
- [x] Fix the inactive wake-lock release crash reported in the Android preview.
- [x] Fix the local conversion flow that remains at 1% instead of continuing to completion.
- [x] Create an updated APK-ready checkpoint containing the wake-lock and conversion-progress fixes.
- [x] Replace the persistent 1% stalled local conversion path with a verified device-compatible implementation.
- [x] Add a browser File API conversion path so the project preview no longer stalls at 1% while preserving the native Android path.
- [x] Complete browser-fallback validation with four passing conversion tests and a clean TypeScript check.
- [ ] Create the final publish-ready checkpoint after the browser fallback validation.
